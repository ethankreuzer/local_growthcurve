Well Corrected Combined dataframe of

    GrowthCurve with Correction 2 (I personally thought this was better than correction 1)
    Enamine with Well Correction 
