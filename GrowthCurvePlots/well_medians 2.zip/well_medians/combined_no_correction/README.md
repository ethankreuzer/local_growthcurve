Combined df_GrowthCurve and df_Enamine with no batch corrections
