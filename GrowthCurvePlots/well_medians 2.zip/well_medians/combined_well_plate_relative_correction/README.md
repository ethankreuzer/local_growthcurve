CORRECTION (Well+Plate Correction):

df_CrowthCurve with correction 4 + df_Enamine with correction 4
