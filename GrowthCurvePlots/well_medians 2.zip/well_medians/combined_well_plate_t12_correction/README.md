CORRECTION (Well+Plate Correction):

df_CrowthCurve with correction 3 + df_Enamine with correction 3
